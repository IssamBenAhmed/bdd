-- Q1-Donner les différents jobs des employés.

-- Q2-Donner le numéro des projets auxquels participe l'employé
-- numéro 7900 avec le nombre d’heures.

-- Q3-Donner le nom et la catégorie des projets avec des employés.

-- Q4-Donner le numéro des projets auxquels participent
-- ADAMS ou MARTIN.

-- Q5-Donner le nom des départements avec des clerk
-- qui travaillent sur le projet 2.

-- Q6-Donner le numéro et le nom des employés dont le salaire et
-- la commission sont égales à celles de l'employé numéro 7654.

-- Q7-Donner le numéro et le nom de tous les départements avec leurs jobs.

-- Q8-Donner le numéro des départements qui n'ont pas d'employé.

-- Q9-Donner le numéro des projets auxquels participent l'employé
-- numéro 7900 et l'employé numéro 7521.

-- Q10-Donner le numéro des projets de la catégorie A
-- ou mobilisant l'employé numéro 7876.

-- Q11-Donner le nom des employés dirigés directement par KING (grâce à la colonne MGR).

-- Q12-Donner le numéro des employés embauchés avant leur manager (colonne MGR).

-- Q13-Donner le nombre de jobs différents.

-- Q14-Donner le salaire moyen et la commission moyenne pour chaque job.

-- Q15-Donner le numéro des projets avec au moins 4 participants.

-- Q16-Donner le numéro des employés dont le nom commence par A
-- et participant à au moins 2 projets.

-- Q17-Donner le nombre de projets par employés (afficher leur numéro
-- et leur nom).

-- Q18-Donner le numéro des employés qui participent à tous les projets.
-- Aide : Compter le nombre de projets auxquels participe chaque employé.

-- Q19-Donner le numéro des employés qui participent à tous les projets
-- de la catégorie C.
-- Aide : Bien compter uniquement les projets de la catégorie C.

-- Q20-Donner le nom des projets de la catégorie B qui mobilisent
-- tous les employés.
